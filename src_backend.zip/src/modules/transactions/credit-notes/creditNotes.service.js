const { pool } = require("../../../db/pool");
const { withTransaction } = require("../../../db/tx");
const { AppError } = require("../../../shared/errors/AppError");
const periodIF = require("../../../interfaces/periodManagement.interface");
const partnerIF = require("../../../interfaces/partnerManagement.interface");
const journalIF = require("../../../interfaces/journalPosting.interface");
const documentableSvc = require("../../../workflow/documents/documentable.service");
const { enrichLines, buildDetailMeta } = require("../_shared/detailEnrichment");
const repo = require("./creditNotes.repository");
const { propagateDocumentWorkflowToJournal } = require("../_shared/workflowJournalAudit.service");
const { resolveLineTaxes, round2, loadLineTaxDetails, summarizeResolvedTaxes } = require("../../../shared/tax/multiTax");
const { multiplyQtyByUnitPriceToMoney, parseDecimalToBigInt, bigIntToDecimalString } = require("../../../shared/utils/money");
const { writeAudit } = require("../../../core/foundation/audit-logs/audit.service");
const { assertSourceNotInFinalizedTaxReturn } = require("../../../shared/tax/taxVoidCompliance");
const fiscalizationSvc = require("../../integrations/fiscalization/fiscalization.service");

async function calcTotals({ client, orgId, lines, payload = {} }) {
  let subtotalCents = 0n;
  let taxTotalCents = 0n;
  for (const l of lines) {
    const qty = l.quantity ?? 1;
    const unitPrice = l.unitPrice ?? 0;
    const lineCents = multiplyQtyByUnitPriceToMoney(qty, unitPrice, 4, 2);
    const lineTotal = bigIntToDecimalString(lineCents, 2);
    l.lineTotal = lineTotal;
    const tax = await resolveLineTaxes({
      client,
      orgId,
      line: l,
      defaultTaxableAmount: lineTotal,
      context: {
        partnerId: payload.customerId || null,
        partnerType: 'customer',
        transactionScope: 'sales',
        documentType: 'credit_note',
        documentDate: payload.creditNoteDate || null,
        supplyType: l.supplyType || payload.supplyType || null,
        jurisdictionId: payload.jurisdictionId || null,
        placeOfSupplyCountryCode: l.placeOfSupplyCountryCode || payload.placeOfSupplyCountryCode || null
      }
    });
    const resolvedTaxSummary = summarizeResolvedTaxes(tax.components);
    const taxableCents = lineCents - parseDecimalToBigInt(resolvedTaxSummary.inclusiveNonWithholdingTax, 2);
    l.taxableAmount = bigIntToDecimalString(taxableCents, 2);
    l.taxAmount = resolvedTaxSummary.totalNonWithholdingTax;
    l.taxCodeId = tax.selectedTaxCodeId || null;
    l.taxDetails = tax.components;
    subtotalCents += taxableCents;
    taxTotalCents += parseDecimalToBigInt(l.taxAmount, 2);
  }
  return {
    subtotal: bigIntToDecimalString(subtotalCents, 2),
    tax_total: bigIntToDecimalString(taxTotalCents, 2),
    total: bigIntToDecimalString(subtotalCents + taxTotalCents, 2)
  };
}

async function getTaxSettings({ orgId, client }) {
  const db = client || pool;
  const { rows } = await db.query(`SELECT * FROM tax_settings WHERE organization_id=$1`, [orgId]);
  return rows[0] || null;
}

async function getCreditNoteBalances({ orgId, creditNoteId, client }) {
  const db = client || pool;
  const { rows } = await db.query(
    `SELECT
        cn.total,
        COALESCE(SUM(cna.amount_applied),0) AS applied
     FROM credit_notes cn
     LEFT JOIN credit_note_applications cna ON cna.credit_note_id = cn.id AND cna.organization_id=cn.organization_id
     WHERE cn.organization_id=$1 AND cn.id=$2
     GROUP BY cn.total`,
    [orgId, creditNoteId]
  );
  if (!rows.length) throw new AppError(404, "Credit note not found");
  const total = Number(rows[0].total || 0);
  const applied = Number(rows[0].applied || 0);
  const remaining = Number((total - applied).toFixed(2));
  return { total, total_amount: total, applied, applied_amount: applied, remaining, remaining_amount: remaining };
}

async function getInvoiceOpenBalance({ orgId, invoiceId, client }) {
  const db = client || pool;
  const { rows } = await db.query(
    `WITH ralloc AS (
      SELECT cra.invoice_id, SUM(cra.amount_applied) AS allocated
      FROM customer_receipt_allocations cra
      JOIN customer_receipts cr ON cr.id = cra.customer_receipt_id
      WHERE cr.organization_id=$1 AND cr.status='posted'
      GROUP BY cra.invoice_id
    ), cnalloc AS (
      SELECT cna.invoice_id, SUM(cna.amount_applied) AS applied
      FROM credit_note_applications cna
      JOIN credit_notes cn ON cn.id = cna.credit_note_id
      WHERE cna.organization_id=$1 AND cn.status='issued'
      GROUP BY cna.invoice_id
    )
    SELECT inv.total,
           COALESCE(ralloc.allocated,0) AS receipts_allocated,
           COALESCE(cnalloc.applied,0) AS credit_applied
      FROM invoices inv
      LEFT JOIN ralloc ON ralloc.invoice_id = inv.id
      LEFT JOIN cnalloc ON cnalloc.invoice_id = inv.id
     WHERE inv.organization_id=$1 AND inv.id=$2`,
    [orgId, invoiceId]
  );
  if (!rows.length) throw new AppError(404, "Invoice not found");
  const total = Number(rows[0].total || 0);
  const allocated = Number(rows[0].receipts_allocated || 0);
  const credit = Number(rows[0].credit_applied || 0);
  return Number((total - allocated - credit).toFixed(2));
}

async function refreshInvoicePaidStatus({ orgId, invoiceId, client }) {
  const open = await getInvoiceOpenBalance({ orgId, invoiceId, client });
  // Only move to PAID if invoice is issued and fully settled.
  await client.query(
    `UPDATE invoices
        SET status = CASE
              WHEN status='issued' AND $3::numeric <= 0::numeric THEN 'paid'
              WHEN status='paid' AND $3::numeric > 0::numeric THEN 'issued'
              ELSE status
            END,
            updated_at=NOW()
      WHERE organization_id=$1 AND id=$2`,
    [orgId, invoiceId, open]
  );
}

async function createDraftCreditNote({ orgId, actorUserId, payload }) {
  // Validate customer
  const customer = await partnerIF.getActiveCustomerForOrg({ orgId, customerId: payload.customerId });
  if (!customer.default_receivable_account_id) throw new AppError(400, "Customer missing defaultReceivableAccountId");

  return withTransaction(async (client) => {
    const totals = await calcTotals({ client, orgId, lines: payload.lines, payload });
    const created = await repo.createDraft({ orgId, actorUserId, payload, totals, client });
    return created;
  });
}

async function updateDraftCreditNote({ orgId, actorUserId, id, payload }) {
  const customer = await partnerIF.getActiveCustomerForOrg({ orgId, customerId: payload.customerId });
  if (!customer.default_receivable_account_id) throw new AppError(400, "Customer missing defaultReceivableAccountId");

  return withTransaction(async (client) => {
    const { rows } = await client.query(`SELECT * FROM credit_notes WHERE organization_id=$1 AND id=$2 FOR UPDATE`, [orgId, id]);
    if (!rows.length) throw new AppError(404, "Credit Note not found");
    const before = rows[0];
    if (before.status !== 'draft') throw new AppError(409, "Only draft credit notes can be edited");

    const totals = await calcTotals({ client, orgId, lines: payload.lines, payload });
    const { rows: updatedRows } = await client.query(
      `UPDATE credit_notes
          SET customer_id=$3, credit_note_date=$4, memo=$5, subtotal=$6, tax_total=$7, total=$8, updated_at=NOW()
        WHERE organization_id=$1 AND id=$2 RETURNING *`,
      [orgId, id, payload.customerId, payload.creditNoteDate, payload.memo || null, totals.subtotal, totals.tax_total, totals.total]
    );
    await client.query(`DELETE FROM credit_note_lines WHERE credit_note_id=$1`, [id]);
    for (let i = 0; i < payload.lines.length; i++) {
      const l = payload.lines[i];
      const { rows: lineRows } = await client.query(
        `INSERT INTO credit_note_lines(
           credit_note_id, line_no, description, quantity, unit_price, line_total, revenue_account_id, tax_code_id, tax_amount, taxable_amount
         ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
        [id, i + 1, l.description, l.quantity ?? 1, l.unitPrice, l.lineTotal, l.revenueAccountId, l.taxCodeId || null, l.taxAmount || 0, l.taxableAmount ?? l.lineTotal ?? 0]
      );
      await require("../../../shared/tax/multiTax").insertLineTaxDetails({ client, tableName: 'credit_note_line_tax_details', lineId: lineRows[0].id, details: l.taxDetails || [] });
    }
    await writeAudit({ organizationId: orgId, actorUserId, action: 'credit_note.draft_updated', entityType: 'credit_notes', entityId: id, before, after: updatedRows[0], client });
    return updatedRows[0];
  });
}

async function listCreditNotes({ orgId, query }) {
  const client = await pool.connect();
  try {
    return await repo.list({ orgId, query, client });
  } finally {
    client.release();
  }
}

async function getCreditNoteDetails({ orgId, id, currentUserId }) {
  const client = await pool.connect();

  try {
    const cn = await repo.getById({
      orgId,
      id,
      currentUserId,
      client
    });

    if (!cn) throw new AppError(404, "Credit note not found");

    const lines = await repo.getLines({ id, client });
    const taxMap = await loadLineTaxDetails({ client, tableName: 'credit_note_line_tax_details', lineIds: lines.map((l) => l.id) });
    const applications = await repo.getApplications({ orgId, id, client });
    const bal = await getCreditNoteBalances({
      orgId,
      creditNoteId: id,
      client
    });

    const enrichedLines = await enrichLines({ client, lines: lines.map((l) => ({ ...l, taxes: taxMap.get(l.id) || [] })) });

    return {
      ...cn,
      lines: enrichedLines,
      applications,
      balance: bal,
      detail_meta: buildDetailMeta({
        header: { ...cn, unapplied_amount: Number((bal?.remaining_amount ?? bal?.remaining ?? 0)) },
        lines: enrichedLines,
        extra: {
          paid: Number((bal?.applied_amount ?? bal?.applied ?? 0)),
          outstanding: Number((bal?.remaining_amount ?? bal?.remaining ?? 0)),
          unapplied_amount: Number((bal?.remaining_amount ?? bal?.remaining ?? 0))
        }
      })
    };

  } finally {
    client.release();
  }
}



async function assertCreditNoteApprovalStateAllowsIssue({ orgId, creditNote, client }) {
  return documentableSvc.assertEntityApprovedForAction({
    orgId,
    entityType: "credit_note",
    workflowDocumentId: creditNote.workflow_document_id,
    client,
    actionLabel: "issue"
  });
}

async function submitCreditNoteForApproval({ orgId, actorUserId, id }) {
  return withTransaction(async (client) => {
    const docEntity = await repo.getById({ orgId, id, client });
    if (!docEntity) throw new AppError(404, "Credit note not found");
    const lines = await repo.getLines({ id, client });
    const taxMap = await loadLineTaxDetails({ client, tableName: 'credit_note_line_tax_details', lineIds: lines.map((l) => l.id) });
    const applications = await repo.getApplications ? await repo.getApplications({ orgId, id, client }) : [];
    await documentableSvc.submitEntityForApproval({
      orgId,
      actorUserId,
      entityType: "credit_note",
      entity: docEntity,
      workflowDocumentId: docEntity.workflow_document_id,
      snapshot: {
        header: docEntity,
        lines: lines.map((l) => ({ ...l, taxes: taxMap.get(l.id) || [] })),
        applications,
        totals: {
          subtotal: docEntity.subtotal,
          tax_total: docEntity.tax_total,
          total: docEntity.total
        },
        meta: {
          status: docEntity.status,
          journal_entry_id: docEntity.journal_entry_id || null,
          period_id: docEntity.period_id || null
        }
      },
      client,
      persistWorkflowDocumentId: async (workflowDocumentId) => {
        await client.query(
          `UPDATE credit_notes SET workflow_document_id=$3, updated_at=NOW() WHERE organization_id=$1 AND id=$2`,
          [orgId, id, workflowDocumentId]
        );
      }
    });

    const { rows } = await client.query(`UPDATE credit_notes SET status='draft', submitted_at=NOW(), submitted_by=$3, approved_at=NULL, approved_by=NULL, rejected_at=NULL, rejected_by=NULL, rejection_reason=NULL, updated_at=NOW() WHERE organization_id=$1 AND id=$2 RETURNING *`, [orgId, id, actorUserId]);
    return rows[0];
  });
}

async function approveCreditNoteWorkflow({ orgId, actorUserId, id, comment }) {
  return withTransaction(async (client) => {
    const docEntity = await repo.getById({ orgId, id, client });
    if (!docEntity) throw new AppError(404, "Credit note not found");
    if (!docEntity.workflow_document_id) throw new AppError(409, "Credit note has no workflow document");

    const approved = await documentableSvc.approveEntityDocument({
      orgId,
      actorUserId,
      entityType: "credit_note",
      workflowDocumentId: docEntity.workflow_document_id,
      creatorUserId: docEntity.created_by,
      comment,
      client
    });

    if (approved?.next) {
      const { rows } = await client.query(`UPDATE credit_notes SET status='submitted', updated_at=NOW() WHERE organization_id=$1 AND id=$2 RETURNING *`, [orgId, id]);
      return rows[0];
    }

    const { rows } = await client.query(`UPDATE credit_notes SET status='approved', approved_at=NOW(), approved_by=$3, updated_at=NOW() WHERE organization_id=$1 AND id=$2 RETURNING *`, [orgId, id, actorUserId]);
    return rows[0];
  });
}

async function rejectCreditNoteWorkflow({ orgId, actorUserId, id, comment }) {
  return withTransaction(async (client) => {
    const docEntity = await repo.getById({ orgId, id, client });
    if (!docEntity) throw new AppError(404, "Credit note not found");
    if (!docEntity.workflow_document_id) throw new AppError(409, "Credit note has no workflow document");

    const rejected = await documentableSvc.rejectEntityDocument({
      orgId,
      actorUserId,
      entityType: "credit_note",
      workflowDocumentId: docEntity.workflow_document_id,
      creatorUserId: docEntity.created_by,
      comment,
      client
    });

    await client.query(
      `UPDATE credit_notes SET status='rejected', rejected_at=NOW(), rejected_by=$3, rejection_reason=$4, updated_at=NOW() WHERE organization_id=$1 AND id=$2`,
      [orgId, id, actorUserId, comment || null]
    );

    const { rows } = await client.query(`UPDATE credit_notes SET status='rejected', rejected_at=NOW(), rejected_by=$3, rejection_reason=$4, updated_at=NOW() WHERE organization_id=$1 AND id=$2 RETURNING *`, [orgId, id, actorUserId, comment || null]);
    return rows[0];
  });
}

async function issueCreditNote({ orgId, actorUserId, id }) {
  return withTransaction(async (client) => {
    const cn = await repo.getById({ orgId, id, client });
    if (!cn) throw new AppError(404, "Credit note not found");
    if (!['draft','approved'].includes(cn.status)) throw new AppError(409, "Only draft/approved credit notes can be issued");

    await assertCreditNoteApprovalStateAllowsIssue({ orgId, creditNote: cn, client });

    const customer = await partnerIF.getActiveCustomerForOrg({ orgId, customerId: cn.customer_id, client });
    if (!customer.default_receivable_account_id) throw new AppError(400, "Customer missing defaultReceivableAccountId");

    const lines = await repo.getLines({ id, client });
    const taxMap = await loadLineTaxDetails({ client, tableName: 'credit_note_line_tax_details', lineIds: lines.map((l) => l.id) });
    if (!lines.length) throw new AppError(400, "Credit note has no lines");

    const taxSettings = await getTaxSettings({ orgId, client });
    const outputTaxAccountId = taxSettings?.output_tax_account_id || null;
    const withholdingReceivableAccountId = taxSettings?.withholding_tax_receivable_account_id || null;

    const period = await periodIF.findOpenPeriodForDate({ orgId, date: cn.credit_note_date, client });

    const postingLines = lines.map((l) => ({ ...l, taxDetails: taxMap.get(l.id) || [] }));
    const { summarizeLineTaxDetails } = require("../../../shared/tax/posting");
    const taxSummary = summarizeLineTaxDetails(postingLines);

    const revenueMap = new Map();
    for (const l of postingLines) {
      const lineTax = taxSummary.byLineId.get(l.id) || { nonRecoverable: 0 };
      const revenueAmount = Number((Number(l.taxable_amount ?? l.line_total ?? 0) + Number(lineTax.nonRecoverable || 0)).toFixed(2));
      revenueMap.set(l.revenue_account_id, (revenueMap.get(l.revenue_account_id) || 0) + revenueAmount);
    }

    const journalLines = [];
    for (const [accountId, amt] of revenueMap.entries()) {
      journalLines.push({ accountId, debit: Number(amt.toFixed(2)), credit: 0, description: `Revenue reversal for ${cn.credit_note_no}` });
    }

    if (taxSummary.outputTax > 0) {
      if (!outputTaxAccountId) throw new AppError(409, "Output tax account is not configured (tax_settings.output_tax_account_id)");
      journalLines.push({ accountId: outputTaxAccountId, debit: taxSummary.outputTax, credit: 0, description: `Output tax reversal for ${cn.credit_note_no}` });
    }

    if (taxSummary.withholdingReceivable > 0) {
      if (!withholdingReceivableAccountId) {
        throw new AppError(409, 'Withholding tax receivable account is not configured (tax_settings.withholding_tax_receivable_account_id)');
      }
      journalLines.push({ accountId: withholdingReceivableAccountId, debit: 0, credit: taxSummary.withholdingReceivable, description: `Withholding tax reversal for ${cn.credit_note_no}` });
    }

    const computedReceivableReduction = Number((journalLines.reduce((sum, line) => sum + Number(line.debit || 0), 0) - journalLines.reduce((sum, line) => sum + Number(line.credit || 0), 0)).toFixed(2));
    if (computedReceivableReduction <= 0) {
      throw new AppError(400, `Computed receivable reduction is invalid for ${cn.credit_note_no}`);
    }
    journalLines.push({ accountId: customer.default_receivable_account_id, debit: 0, credit: computedReceivableReduction, description: `A/R reversal for ${cn.credit_note_no}` });

    const idempotencyKey = `credit_note:${id}:issue`;
    const draft = await journalIF.createDraftJournal({
      orgId,
      actorUserId,
      client,
      payload: {
        periodId: period.id,
        entryDate: cn.credit_note_date,
        typeCode: 'GENERAL',
        memo: `Credit Note ${cn.credit_note_no}` + (cn.memo ? `: ${cn.memo}` : ''),
        idempotencyKey,
        lines: journalLines
      }
    });

    await propagateDocumentWorkflowToJournal({
      client,
      journalId: draft.journalId,
      source: {
        orgId,
        workflowDocumentId: cn.workflow_document_id || null,
        createdBy: cn.created_by || actorUserId,
        submittedAt: cn.submitted_at || null,
        submittedBy: cn.submitted_by || null,
        approvedAt: cn.approved_at || null,
        approvedBy: cn.approved_by || null,
        updatedBy: actorUserId
      }
    });

    const posted = await journalIF.postDraftJournal({ orgId, journalId: draft.journalId, actorUserId, client });

    const issued = await repo.setIssued({
      orgId,
      id,
      periodId: period.id,
      journalEntryId: posted.journalId,
      actorUserId,
      client
    });
    await writeAudit({
      organizationId: orgId, actorUserId, action: "credit_note.issued",
      entityType: "credit_notes", entityId: id, before: cn, after: issued, client
    });
    return issued;
  });
}

async function applyCreditNote({ orgId, actorUserId, id, payload }) {
  return withTransaction(async (client) => {
    const amountAppliedCents = parseDecimalToBigInt(payload?.amountApplied ?? payload?.amount_applied ?? payload?.amount ?? '0', 2);
    const normalizedPayload = {
      invoiceId: String(payload?.invoiceId ?? payload?.invoice_id ?? '').trim(),
      amountApplied: bigIntToDecimalString(amountAppliedCents, 2)
    };
    if (!normalizedPayload.invoiceId) throw new AppError(400, "invoiceId is required");
    if (amountAppliedCents <= 0n) {
      throw new AppError(400, "amountApplied must be > 0", null, "validation_error");
    }

    const cn = await repo.getById({ orgId, id, client });
    if (!cn) throw new AppError(404, "Credit note not found");
    if (cn.status !== 'issued') throw new AppError(409, "Only issued credit notes can be applied");

    const { rows: invRows } = await client.query(
      `SELECT * FROM invoices WHERE organization_id=$1 AND id=$2`,
      [orgId, normalizedPayload.invoiceId]
    );
    if (!invRows.length) throw new AppError(404, "Invoice not found");
    const inv = invRows[0];
    if (inv.customer_id !== cn.customer_id) throw new AppError(409, "Invoice customer does not match credit note customer");
    if (inv.status === 'voided') throw new AppError(409, "Cannot apply to voided invoice");

    const cnBal = await getCreditNoteBalances({ orgId, creditNoteId: id, client });
    if (amountAppliedCents > parseDecimalToBigInt(cnBal.remaining ?? '0', 2)) throw new AppError(409, "Amount exceeds credit note remaining balance");

    const invOpen = await getInvoiceOpenBalance({ orgId, invoiceId: normalizedPayload.invoiceId, client });
    if (amountAppliedCents > parseDecimalToBigInt(invOpen ?? '0', 2)) throw new AppError(409, "Amount exceeds invoice open balance");

    const app = await repo.insertApplication({
      orgId,
      creditNoteId: id,
      invoiceId: normalizedPayload.invoiceId,
      amountApplied: normalizedPayload.amountApplied,
      actorUserId,
      client
    });

    await refreshInvoicePaidStatus({ orgId, invoiceId: normalizedPayload.invoiceId, client });
    const balance = await getCreditNoteBalances({ orgId, creditNoteId: id, client });
    const result = { ...app, balance, is_available_for_application: balance.remaining > 0 };
    await writeAudit({
      organizationId: orgId, actorUserId, action: "credit_note.applied",
      entityType: "credit_notes", entityId: id, before: cn, after: result, client
    });
    return result;
  });
}

async function voidCreditNote({ orgId, actorUserId, id, reason }) {
  return withTransaction(async (client) => {
    const cn = await repo.getById({ orgId, id, client });
    if (!cn) throw new AppError(404, "Credit note not found");
    if (cn.status !== 'issued') throw new AppError(409, "Only issued credit notes can be voided");

    const { rows: apps } = await client.query(
      `SELECT 1 FROM credit_note_applications WHERE organization_id=$1 AND credit_note_id=$2 LIMIT 1`,
      [orgId, id]
    );
    if (apps.length) throw new AppError(409, "Cannot void a credit note that has been applied");

    await assertSourceNotInFinalizedTaxReturn({ client, orgId, sourceType: "credit_note", sourceId: id });
    await fiscalizationSvc.prepareSourceForVoid({ db: client, orgId, actorUserId, sourceType: "credit_note", sourceId: id });

    if (!cn.journal_entry_id) throw new AppError(409, "Credit note has no journal entry to reverse");
    const rev = await journalIF.voidPostedJournal({
      orgId,
      journalId: cn.journal_entry_id,
      actorUserId,
      reason: reason || "Void credit note",
      client
    });

    const out = await repo.setVoided({
      orgId,
      id,
      reversalJournalEntryId: rev.reversalJournalId,
      actorUserId,
      reason: reason || null,
      client
    });
    await writeAudit({
      organizationId: orgId, actorUserId, action: "credit_note.voided",
      entityType: "credit_notes", entityId: id, before: cn, after: out, client
    });
    return out;
  });
}

module.exports = {
  createDraftCreditNote,
  updateDraftCreditNote,
  listCreditNotes,
  getCreditNoteDetails,
  submitCreditNoteForApproval,
  approveCreditNoteWorkflow,
  rejectCreditNoteWorkflow,
  assertCreditNoteApprovalStateAllowsIssue,
  issueCreditNote,
  applyCreditNote,
  voidCreditNote
};
