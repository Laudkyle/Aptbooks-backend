const express = require("express");
const { authRequired } = require("../../middleware/auth.middleware");
const { requirePermission } = require("../../middleware/permission.middleware");
const { idempotency } = require("../../middleware/idempotency.middleware");
const { validate } = require("../../shared/validators/validate");

const svc = require("./ifrs15.service");
const v = require("./ifrs15.validators");

const router = express.Router();

router.use(authRequired);
const requireMutationIdempotency = idempotency({ required: true });
router.use((req, res, next) => {
  if (!["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) return next();
  return requireMutationIdempotency(req, res, next);
});

// Settings
router.get(
  "/settings",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const data = await svc.getSettings({ orgId: req.user.organization_id });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.put(
  "/settings",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const payload = validate(v.upsertSettings, req.body);
      const data = await svc.upsertSettings({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        payload,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

// Contracts
router.post(
  "/contracts/:contractId/submit-for-approval",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const data = await svc.submitContractForApproval({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/approve",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const data = await svc.approveContractWorkflow({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, comment: req.body?.comment || null });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/reject",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const data = await svc.rejectContractWorkflow({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, comment: req.body?.comment || null });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.get(
  "/contracts",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const query = validate(v.listContractsQuery, req.query);
      const data = await svc.listContracts({ orgId: req.user.organization_id, query });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.post(
  "/contracts",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const payload = validate(v.createContract, req.body);
      const data = await svc.createContract({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        payload,
      });
      res.status(201).json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.get(
  "/contracts/:contractId",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const data = await svc.getContract({ orgId: req.user.organization_id, contractId: params.contractId });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.put(
  "/contracts/:contractId",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const payload = validate(v.updateContract, req.body);
      const data = await svc.updateContract({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload,
      });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.patch(
  "/contracts/:contractId",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const payload = validate(v.updateContract, req.body);
      const data = await svc.updateContract({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload,
      });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.delete(
  "/contracts/:contractId",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const data = await svc.deleteContract({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/lifecycle",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const payload = validate(v.lifecycleAction, req.body);
      const data = await svc.updateContractLifecycle({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.post(
  "/contracts/:contractId/obligations",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const payload = validate(v.addObligation, { ...req.body, ...params });
      const data = await svc.addObligation({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload,
      });
      res.status(201).json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.put(
  "/contracts/:contractId/obligations/:obligationId",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.obligationIdParam, req.params);
      const payload = validate(v.updateObligation, req.body);
      const data = await svc.updateObligation({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, obligationId: params.obligationId, payload });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.delete(
  "/contracts/:contractId/obligations/:obligationId",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.obligationIdParam, req.params);
      const data = await svc.deleteObligation({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, obligationId: params.obligationId });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/activate",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const payload = validate(v.activateContract, { ...req.body, ...params });
      const data = await svc.activateContract({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.post(
  "/contracts/:contractId/schedule/generate",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const payload = validate(v.generateSchedule, { ...req.body, ...params });
      const data = await svc.generateSchedule({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.get(
  "/contracts/:contractId/schedule",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const data = await svc.getSchedule({ orgId: req.user.organization_id, contractId: params.contractId });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.post(
  "/contracts/:contractId/post",
  requirePermission("compliance.ifrs15.post"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const body = validate(v.postRevenue, req.body);
      const data = await svc.postRevenueForPeriod({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload: body,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

// --------------------
// Stage 2 extensions
// --------------------

router.post(
  "/contracts/:contractId/modifications",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const payload = validate(v.createModification, { ...req.body, ...params });
      const data = await svc.createModification({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload,
      });
      res.status(201).json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.put(
  "/contracts/:contractId/modifications/:modificationId",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.modificationIdParam, req.params);
      const payload = validate(v.updateModification, req.body);
      const data = await svc.updateModification({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, modificationId: params.modificationId, payload });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/modifications/:modificationId/submit-for-approval",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.modificationIdParam, req.params);
      const data = await svc.submitModification({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, modificationId: params.modificationId });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/modifications/:modificationId/approve",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.modificationIdParam, req.params);
      const payload = validate(v.modificationDecision, req.body || {});
      const data = await svc.approveModification({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, modificationId: params.modificationId, payload });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/modifications/:modificationId/reject",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.modificationIdParam, req.params);
      const payload = validate(v.modificationDecision, req.body || {});
      const data = await svc.rejectModification({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, modificationId: params.modificationId, payload });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.delete(
  "/contracts/:contractId/modifications/:modificationId",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.modificationIdParam, req.params);
      const data = await svc.deleteModification({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, modificationId: params.modificationId });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/modifications/:modificationId/apply",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.modificationIdParam, req.params);
      const payload = validate(v.applyModification, req.body);
      const data = await svc.applyModification({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        modificationId: params.modificationId,
        payload,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.get(
  "/contracts/:contractId/modifications",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const data = await svc.listModifications({ orgId: req.user.organization_id, contractId: params.contractId });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/variable-consideration",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const payload = validate(v.createVariableConsideration, { ...req.body, ...params });
      const data = await svc.createVariableConsideration({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload,
      });
      res.status(201).json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.put(
  "/contracts/:contractId/variable-consideration/:variableConsiderationId",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.variableConsiderationIdParam, req.params);
      const payload = validate(v.updateVariableConsideration, req.body);
      const data = await svc.updateVariableConsideration({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, variableConsiderationId: params.variableConsiderationId, payload });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.delete(
  "/contracts/:contractId/variable-consideration/:variableConsiderationId",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.variableConsiderationIdParam, req.params);
      const data = await svc.deleteVariableConsideration({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, variableConsiderationId: params.variableConsiderationId });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/variable-consideration/:variableConsiderationId/review",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.variableConsiderationIdParam, req.params);
      const payload = validate(v.reviewVariableConsideration, req.body);
      const data = await svc.reviewVariableConsideration({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        variableConsiderationId: params.variableConsiderationId,
        payload,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.post(
  "/contracts/:contractId/variable-consideration/:variableConsiderationId/approve",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.variableConsiderationIdParam, req.params);
      const payload = validate(v.approveVariableConsideration, req.body);
      const data = await svc.approveVariableConsideration({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        variableConsiderationId: params.variableConsiderationId,
        payload,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.post(
  "/contracts/:contractId/variable-consideration/apply",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const payload = validate(v.applyVariableConsideration, req.body);
      const data = await svc.applyVariableConsideration({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.get(
  "/contracts/:contractId/variable-consideration",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const data = await svc.listVariableConsideration({ orgId: req.user.organization_id, contractId: params.contractId });
      res.json(data);
    } catch (e) { next(e); }
  }
);
router.put(
  "/contracts/:contractId/financing-terms",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const payload = validate(v.setFinancingTerms, { ...req.body, ...params });
      const data = await svc.setFinancingTerms({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.get(
  "/contracts/:contractId/financing-terms",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const data = await svc.listFinancingTerms({ orgId: req.user.organization_id, contractId: params.contractId });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/financing/post",
  requirePermission("compliance.ifrs15.post"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const payload = validate(v.postFinancing, req.body);
      const data = await svc.postFinancingForPeriod({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.post(
  "/contracts/:contractId/costs",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const payload = validate(v.createCost, { ...req.body, ...params });
      const data = await svc.createCost({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        payload,
      });
      res.status(201).json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.get(
  "/contracts/:contractId/costs",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const data = await svc.listCosts({ orgId: req.user.organization_id, contractId: params.contractId });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.put(
  "/contracts/:contractId/costs/:costId",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.costIdParam, req.params);
      const payload = validate(v.updateCost, { ...req.body, ...params });
      const data = await svc.updateCost({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, costId: params.costId, payload });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.delete(
  "/contracts/:contractId/costs/:costId",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.costIdParam, req.params);
      const data = await svc.deleteCost({ orgId: req.user.organization_id, actorUserId: req.user.id, contractId: params.contractId, costId: params.costId });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/costs/:costId/schedule/generate",
  requirePermission("compliance.ifrs15.manage"),
  async (req, res, next) => {
    try {
      const params = validate(v.costIdParam, req.params);
      const payload = validate(v.generateCostSchedule, { ...req.body, ...params });
      const data = await svc.generateCostSchedule({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        costId: params.costId,
        payload,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.get(
  "/contracts/:contractId/costs/:costId/schedule",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const params = validate(v.costIdParam, req.params);
      const data = await svc.getCostSchedule({ orgId: req.user.organization_id, contractId: params.contractId, costId: params.costId });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.get(
  "/contracts/:contractId/posting-ledger",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const data = await svc.getPostingLedger({ orgId: req.user.organization_id, contractId: params.contractId });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.get(
  "/contracts/:contractId/events",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const params = validate(v.contractIdParam, req.params);
      const data = await svc.getContractEvents({ orgId: req.user.organization_id, contractId: params.contractId });
      res.json(data);
    } catch (e) { next(e); }
  }
);

router.post(
  "/contracts/:contractId/costs/:costId/post",
  requirePermission("compliance.ifrs15.post"),
  async (req, res, next) => {
    try {
      const params = validate(v.costIdParam, req.params);
      const payload = validate(v.postCostAmort, req.body);
      const data = await svc.postCostAmortForPeriod({
        orgId: req.user.organization_id,
        actorUserId: req.user.id,
        contractId: params.contractId,
        costId: params.costId,
        payload,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.get(
  "/reports/contract-rollforward",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const q = validate(v.rollforwardReport, req.query);
      const data = await svc.contractRollforwardReport({ orgId: req.user.organization_id, periodId: q.period_id });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.get(
  "/reports/remaining-performance-obligations",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const q = validate(v.rpoReport, req.query);
      const data = await svc.remainingPerformanceObligationsReport({
        orgId: req.user.organization_id,
        asOfPeriodId: q.as_of_period_id,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.get(
  "/reports/revenue-disaggregation",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const q = validate(v.revenueDisaggregationReport, req.query);
      const data = await svc.revenueDisaggregationReport({
        orgId: req.user.organization_id,
        periodId: q.period_id,
        dimension: q.dimension,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

router.get(
  "/reports/judgements",
  requirePermission("compliance.ifrs15.read"),
  async (req, res, next) => {
    try {
      const q = validate(v.judgementsReport, req.query);
      const data = await svc.judgementsReport({
        orgId: req.user.organization_id,
        asOfDate: q.as_of_date,
      });
      res.json(data);
    } catch (e) {
      next(e);
    }
  }
);

module.exports = router;
