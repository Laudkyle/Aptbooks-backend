const { pool } = require("../../../db/pool");
const { AppError } = require("../../../shared/errors/AppError");
const { parseDecimalToBigInt, bigIntToDecimalString } = require("../../../shared/utils/money");

async function getOrgBaseCurrency(client, orgId) {
  const { rows } = await client.query(
    `SELECT base_currency_code FROM organizations WHERE id=$1`,
    [orgId]
  );
  if (!rows.length) throw new AppError(400, "Invalid organization");
  return rows[0].base_currency_code;
}

function sum2(lines) {
  return lines.reduce(
    (acc, l) => {
      acc.debit += parseDecimalToBigInt(l.debit || 0, 2);
      acc.credit += parseDecimalToBigInt(l.credit || 0, 2);
      return acc;
    },
    { debit: 0n, credit: 0n }
  );
}

async function getPeriodForUpdate(client, orgId, periodId) {
  const { rows } = await client.query(
    `SELECT id, status, start_date, end_date FROM accounting_periods WHERE organization_id=$1 AND id=$2 FOR SHARE`,
    [orgId, periodId]
  );
  if (!rows.length) throw new AppError(400, "Invalid period");
  return rows[0];
}

function assertEntryDateWithinPeriod(entryDate, period) {
  const d = new Date(entryDate + "T00:00:00Z").getTime();
  const s = new Date(period.start_date + "T00:00:00Z").getTime();
  const e = new Date(period.end_date + "T00:00:00Z").getTime();
  if (d < s || d > e) throw new AppError(409, "entryDate must be within the selected period");
}

async function createDraftJournal({ orgId, actorUserId, payload, client: existingClient = null }) {
  const client = existingClient || (await pool.connect());
  const managesTx = !existingClient;
  try {
    if (managesTx) await client.query("BEGIN");

    const baseCurrency = await getOrgBaseCurrency(client, orgId);

    // idempotency
    if (payload.idempotencyKey) {
      const { rows: existing } = await client.query(
        `SELECT id, status FROM journal_entries WHERE organization_id=$1 AND idempotency_key=$2`,
        [orgId, payload.idempotencyKey]
      );
      if (existing.length) {
        if (managesTx) await client.query("COMMIT");
        return { journalId: existing[0].id, status: existing[0].status, idempotent: true };
      }
    }

    const period = await getPeriodForUpdate(client, orgId, payload.periodId);
    if (period.status !== "open") throw new AppError(409, "Period not open");
    assertEntryDateWithinPeriod(payload.entryDate, period);

    const { rows: tRows } = await client.query(
      `SELECT id FROM journal_entry_types WHERE code=$1`,
      [payload.typeCode || "GENERAL"]
    );
    if (!tRows.length) throw new AppError(400, "Invalid journal entry type");
    const typeId = tRows[0].id;

    const totals = sum2(payload.lines || []);
    if (totals.debit !== totals.credit) throw new AppError(400, "Journal not balanced");

    // Validate accounts exist and are postable+active up front
    for (const l of payload.lines) {
      const { rows: aRows } = await client.query(
        `SELECT is_postable, status FROM chart_of_accounts WHERE organization_id=$1 AND id=$2`,
        [orgId, l.accountId]
      );
      if (!aRows.length) throw new AppError(400, "Invalid accountId");
      if (!aRows[0].is_postable) throw new AppError(400, "Non-postable account used");
      if (aRows[0].status !== "active") throw new AppError(400, "Inactive account used");
    }

    const { rows: jRows } = await client.query(
      `
      INSERT INTO journal_entries
        (organization_id, journal_entry_type_id, period_id, entry_date, memo, status, idempotency_key, created_by)
      VALUES ($1,$2,$3,$4,$5,'draft',$6,$7)
      RETURNING id, status
      `,
      [orgId, typeId, payload.periodId, payload.entryDate, payload.memo || null, payload.idempotencyKey || null, actorUserId]
    );
    const journalId = jRows[0].id;

    for (let i = 0; i < payload.lines.length; i++) {
      const l = payload.lines[i];
      const debitBI = parseDecimalToBigInt(l.debit || 0, 2);
      const creditBI = parseDecimalToBigInt(l.credit || 0, 2);
      const amountBaseBI = debitBI > 0n ? debitBI : creditBI;

      const debit = bigIntToDecimalString(debitBI, 2);
      const credit = bigIntToDecimalString(creditBI, 2);
      const amountBase = bigIntToDecimalString(amountBaseBI, 2);

      await client.query(
        `
        INSERT INTO journal_entry_lines
          (journal_entry_id, line_no, account_id, description, debit, credit, currency_code, fx_rate, amount_base)
        VALUES ($1,$2,$3,$4,$5,$6,$7,1,$8)
        `,
        [journalId, i + 1, l.accountId, l.description || null, debit, credit, baseCurrency, amountBase]
      );
    }

    if (managesTx) await client.query("COMMIT");
    return { journalId, status: "draft" };
  } catch (e) {
    if (managesTx) {
      try { await client.query("ROLLBACK"); } catch (_) {}
    }
    throw e;
  } finally {
    if (managesTx) client.release();
  }
}

async function postDraftJournal({ orgId, journalId, actorUserId, client: existingClient = null }) {
  const client = existingClient || (await pool.connect());
  const managesTx = !existingClient;
  try {
    if (managesTx) await client.query("BEGIN");

    const baseCurrency = await getOrgBaseCurrency(client, orgId);
    // NOTE: avoid console logging in production paths (keep silent here)
    const { rows: jRows } = await client.query(
      `
      SELECT id, status, period_id, entry_date, created_by
      FROM journal_entries
      WHERE organization_id=$1 AND id=$2
      FOR UPDATE
      `,
      [orgId, journalId]
    );
    if (!jRows.length) throw new AppError(404, "Journal not found");
    const journal = jRows[0];
    if (!['draft','approved'].includes(journal.status)) {
      throw new AppError(409, "Journal must be in draft or approved status to post");
    }
    if (journal.created_by && String(journal.created_by) === String(actorUserId)) {
      // Maker-checker: creator cannot post their own journal
      throw new AppError(403, "Segregation of duties: creator cannot post this journal");
    }

    const period = await getPeriodForUpdate(client, orgId, journal.period_id);
    if (period.status !== "open") throw new AppError(409, "Period not open");
    assertEntryDateWithinPeriod(journal.entry_date, period);

    const { rows: lines } = await client.query(
      `
      SELECT jel.account_id, jel.debit, jel.credit, jel.currency_code,
             coa.is_postable, coa.status AS account_status
      FROM journal_entry_lines jel
      JOIN chart_of_accounts coa
        ON coa.id = jel.account_id AND coa.organization_id = $1
      WHERE jel.journal_entry_id = $2
      ORDER BY jel.line_no
      `,
      [orgId, journalId]
    );
    if (!lines.length) throw new AppError(400, "Journal has no lines");

    for (const l of lines) {
      if (l.currency_code !== baseCurrency) {
        throw new AppError(400, `Phase 1 supports base currency only (${baseCurrency})`);
      }
      if (!l.is_postable) throw new AppError(400, "Non-postable account used");
      if (l.account_status !== "active") throw new AppError(400, "Inactive account used");
    }

    const totals = sum2(lines);
    if (totals.debit !== totals.credit) throw new AppError(400, "Journal not balanced");

    for (const l of lines) {
      const debit = l.debit || "0";
      const credit = l.credit || "0";

      await client.query(
        `
        INSERT INTO general_ledger_balances
          (organization_id, period_id, account_id, debit_total, credit_total)
        VALUES ($1,$2,$3,$4,$5)
        ON CONFLICT (organization_id, period_id, account_id)
        DO UPDATE SET
          debit_total = general_ledger_balances.debit_total + EXCLUDED.debit_total,
          credit_total = general_ledger_balances.credit_total + EXCLUDED.credit_total
        `,
        [orgId, journal.period_id, l.account_id, debit, credit]
      );
    }

    await client.query(
      `
      UPDATE journal_entries
      SET status='posted', posted_at=NOW(), posted_by=$3
      WHERE organization_id=$1 AND id=$2
      `,
      [orgId, journalId, actorUserId]
    );

    if (managesTx) await client.query("COMMIT");
    return { journalId, status: "posted" };
  } catch (e) {
    if (managesTx) {
      try { await client.query("ROLLBACK"); } catch (_) {}
    }
    throw e;
  } finally {
    if (managesTx) client.release();
  }
}

/**
 * Accounting-correct void: create and post a reversal journal.
 * - Requires original journal is POSTED and not already voided.
 * - Reversal journal is posted immediately in the SAME period.
 * - Original journal is marked voided with link via memo and void_reason.
 */
async function voidByReversal({ orgId, journalId, actorUserId, reason, client: existingClient = null }) {
  const client = existingClient || (await pool.connect());
  const managesTx = !existingClient;
  try {
    if (managesTx) await client.query("BEGIN");

    const baseCurrency = await getOrgBaseCurrency(client, orgId);

    const { rows: jRows } = await client.query(
      `
      SELECT id, status, period_id, entry_date, memo, journal_entry_type_id
      FROM journal_entries
      WHERE organization_id=$1 AND id=$2
      FOR UPDATE
      `,
      [orgId, journalId]
    );
    if (!jRows.length) throw new AppError(404, "Journal not found");
    const orig = jRows[0];
    if (orig.status !== "posted") throw new AppError(409, "Only posted journals can be voided");

    const period = await getPeriodForUpdate(client, orgId, orig.period_id);
    if (period.status !== "open") throw new AppError(409, "Period not open; cannot create reversal in this period");

    const { rows: lines } = await client.query(
      `
      SELECT line_no, account_id, description, debit, credit, currency_code
      FROM journal_entry_lines
      WHERE journal_entry_id=$1
      ORDER BY line_no
      `,
      [journalId]
    );
    if (!lines.length) throw new AppError(400, "Journal has no lines");
    for (const l of lines) {
      if (l.currency_code !== baseCurrency) {
        throw new AppError(400, `Phase 1 supports base currency only (${baseCurrency})`);
      }
    }

    // Create reversal journal (draft)
    const reversalMemo = `Reversal of JE ${journalId}. Reason: ${reason}`;
    const { rows: revRows } = await client.query(
      `
      INSERT INTO journal_entries
        (organization_id, journal_entry_type_id, period_id, entry_date, memo, status)
      VALUES ($1,$2,$3,$4,$5,'draft')
      RETURNING id
      `,
      [orgId, orig.journal_entry_type_id, orig.period_id, orig.entry_date, reversalMemo]
    );
    const reversalId = revRows[0].id;

    // Reverse lines: swap debit/credit
    for (const l of lines) {
      const debitBI = parseDecimalToBigInt(l.debit || 0, 2);
      const creditBI = parseDecimalToBigInt(l.credit || 0, 2);
      const newDebitBI = creditBI;
      const newCreditBI = debitBI;
      const amountBaseBI = newDebitBI > 0n ? newDebitBI : newCreditBI;

      const newDebit = bigIntToDecimalString(newDebitBI, 2);
      const newCredit = bigIntToDecimalString(newCreditBI, 2);
      const amountBase = bigIntToDecimalString(amountBaseBI, 2);

      await client.query(
        `
        INSERT INTO journal_entry_lines
          (journal_entry_id, line_no, account_id, description, debit, credit, currency_code, fx_rate, amount_base)
        VALUES ($1,$2,$3,$4,$5,$6,$7,1,$8)
        `,
        [reversalId, l.line_no, l.account_id, `REV: ${l.description || ""}`.trim(), newDebit, newCredit, baseCurrency, amountBase]
      );
    }

    // Post reversal (update GL)
    // Fetch reversal lines for posting
    const { rows: revLines } = await client.query(
      `
      SELECT account_id, debit, credit
      FROM journal_entry_lines
      WHERE journal_entry_id=$1
      ORDER BY line_no
      `,
      [reversalId]
    );

    const totals = sum2(revLines);
    if (totals.debit !== totals.credit) throw new AppError(500, "Reversal journal not balanced (unexpected)");

    for (const l of revLines) {
      await client.query(
        `
        INSERT INTO general_ledger_balances
          (organization_id, period_id, account_id, debit_total, credit_total)
        VALUES ($1,$2,$3,$4,$5)
        ON CONFLICT (organization_id, period_id, account_id)
        DO UPDATE SET
          debit_total = general_ledger_balances.debit_total + EXCLUDED.debit_total,
          credit_total = general_ledger_balances.credit_total + EXCLUDED.credit_total
        `,
        [orgId, orig.period_id, l.account_id, l.debit || "0", l.credit || "0"]
      );
    }

    await client.query(
      `
      UPDATE journal_entries
      SET status='posted', posted_at=NOW(), posted_by=$2
      WHERE organization_id=$1 AND id=$3
      `,
      [orgId, actorUserId, reversalId]
    );

    // Mark original voided (for UX/reporting; GL is corrected by reversal)
    // Mark original voided (for UX/reporting; GL is corrected by reversal)
// IMPORTANT: Do NOT modify memo or any other non-void field (immutability trigger)
await client.query(
  `
  UPDATE journal_entries
  SET status='voided',
      voided_at=NOW(),
      voided_by=$3,
      void_reason=$4,
      updated_at=NOW()
  WHERE organization_id=$1
    AND id=$2
    AND status='posted'
  `,
  [orgId, journalId, actorUserId, `Reversed by JE ${reversalId}. Reason: ${reason}`]
);


    if (managesTx) await client.query("COMMIT");
    return { journalId, status: "voided", reversalJournalId: reversalId };
  } catch (e) {
    if (managesTx) {
      try { await client.query("ROLLBACK"); } catch (_) {}
    }
    throw e;
  } finally {
    if (managesTx) client.release();
  }
}
async function reversePostedJournal({ orgId, journalId, actorUserId, targetPeriodId, entryDate, reason, idempotencyKey, client: existingClient = null }) {
  const client = existingClient || (await pool.connect());
  const managesTx = !existingClient;
  try {
    if (managesTx) await client.query("BEGIN");

    const baseCurrency = await getOrgBaseCurrency(client, orgId);

    // 1) Load original (lock)
    const { rows: jRows } = await client.query(
      `
      SELECT id, status, period_id, entry_date, memo, journal_entry_type_id
      FROM journal_entries
      WHERE organization_id=$1 AND id=$2
      FOR UPDATE
      `,
      [orgId, journalId]
    );
    if (!jRows.length) throw new AppError(404, "Journal not found");
    const orig = jRows[0];
    if (orig.status !== "posted") throw new AppError(409, "Only posted journals can be reversed");

    // 2) Target period must be open (reversal posts there)
    const targetPeriod = await getPeriodForUpdate(client, orgId, targetPeriodId);
    if (targetPeriod.status !== "open") throw new AppError(409, "Target period not open; cannot post reversal");

    // 3) Idempotency: if reversal already exists, return it
    if (idempotencyKey) {
      const { rows: existing } = await client.query(
        `
        SELECT id
        FROM journal_entries
        WHERE organization_id=$1 AND idempotency_key=$2
        LIMIT 1
        `,
        [orgId, idempotencyKey]
      );
      if (existing.length) {
        if (managesTx) await client.query("COMMIT");
        return { reversalJournalId: existing[0].id, alreadyExisted: true };
      }
    }

    // 4) Load original lines
    const { rows: lines } = await client.query(
      `
      SELECT line_no, account_id, description, debit, credit, currency_code
      FROM journal_entry_lines
      WHERE journal_entry_id=$1
      ORDER BY line_no
      `,
      [journalId]
    );
    if (!lines.length) throw new AppError(400, "Journal has no lines");
    for (const l of lines) {
      if (l.currency_code !== baseCurrency) {
        throw new AppError(400, `Phase 1 supports base currency only (${baseCurrency})`);
      }
    }

    // 5) Create reversal journal in TARGET period/date
    const reversalMemo = `Reversal of JE ${journalId}. Reason: ${reason || "n/a"}`;
    const { rows: revRows } = await client.query(
      `
      INSERT INTO journal_entries
        (organization_id, journal_entry_type_id, period_id, entry_date, memo, status, idempotency_key)
      VALUES ($1,$2,$3,$4,$5,'draft',$6)
      RETURNING id
      `,
      [orgId, orig.journal_entry_type_id, targetPeriodId, entryDate, reversalMemo, idempotencyKey || null]
    );
    const reversalId = revRows[0].id;

    // 6) Insert reversed lines
    for (const l of lines) {
      const debitBI = parseDecimalToBigInt(l.debit || 0, 2);
      const creditBI = parseDecimalToBigInt(l.credit || 0, 2);
      const newDebitBI = creditBI;
      const newCreditBI = debitBI;
      const amountBaseBI = newDebitBI > 0n ? newDebitBI : newCreditBI;

      const newDebit = bigIntToDecimalString(newDebitBI, 2);
      const newCredit = bigIntToDecimalString(newCreditBI, 2);
      const amountBase = bigIntToDecimalString(amountBaseBI, 2);

      await client.query(
        `
        INSERT INTO journal_entry_lines
          (journal_entry_id, line_no, account_id, description, debit, credit, currency_code, fx_rate, amount_base)
        VALUES ($1,$2,$3,$4,$5,$6,$7,1,$8)
        `,
        [reversalId, l.line_no, l.account_id, `REV: ${l.description || ""}`.trim(), newDebit, newCredit, baseCurrency, amountBase]
      );
    }

    // 7) Post reversal into GL balances for TARGET period
    const { rows: revLines } = await client.query(
      `SELECT account_id, debit, credit FROM journal_entry_lines WHERE journal_entry_id=$1 ORDER BY line_no`,
      [reversalId]
    );
    const totals = sum2(revLines);
    if (totals.debit !== totals.credit) throw new AppError(500, "Reversal journal not balanced (unexpected)");

    for (const l of revLines) {
      await client.query(
        `
        INSERT INTO general_ledger_balances
          (organization_id, period_id, account_id, debit_total, credit_total)
        VALUES ($1,$2,$3,$4,$5)
        ON CONFLICT (organization_id, period_id, account_id)
        DO UPDATE SET
          debit_total = general_ledger_balances.debit_total + EXCLUDED.debit_total,
          credit_total = general_ledger_balances.credit_total + EXCLUDED.credit_total
        `,
        [orgId, targetPeriodId, l.account_id, l.debit || "0", l.credit || "0"]
      );
    }

    await client.query(
      `
      UPDATE journal_entries
      SET status='posted', posted_at=NOW(), posted_by=$2
      WHERE organization_id=$1 AND id=$3
      `,
      [orgId, actorUserId, reversalId]
    );

    // 8) IMPORTANT: Do NOT modify original journal status
    if (managesTx) await client.query("COMMIT");
    return { reversalJournalId: reversalId, alreadyExisted: false };
  } catch (e) {
    if (managesTx) {
      try { await client.query("ROLLBACK"); } catch (_) {}
    }
    throw e;
  } finally {
    if (managesTx) client.release();
  }
}

// ---------------------------------
// Stage 2: Draft editing + lifecycle
// ---------------------------------

async function getJournalWithLines({ orgId, journalId }) {
  const { rows: j } = await pool.query(
    `SELECT * FROM journal_entries WHERE organization_id=$1 AND id=$2`,
    [orgId, journalId]
  );
  if (!j.length) throw new AppError(404, "Journal not found");
  const { rows: lines } = await pool.query(
    `SELECT * FROM journal_entry_lines WHERE journal_entry_id=$1 ORDER BY line_no`,
    [journalId]
  );
  return { journal: j[0], lines };
}

async function assertEditableJournal(client, { orgId, journalId }) {
  const { rows: jRows } = await client.query(
    `SELECT id, status, period_id, entry_date, created_by FROM journal_entries WHERE organization_id=$1 AND id=$2 FOR UPDATE`,
    [orgId, journalId]
  );
  if (!jRows.length) throw new AppError(404, "Journal not found");
  const j = jRows[0];
  if (!["draft", "rejected"].includes(j.status)) {
    throw new AppError(409, "Only draft/rejected journals can be edited");
  }
  const period = await getPeriodForUpdate(client, orgId, j.period_id);
  if (period.status !== "open") throw new AppError(409, "Period not open");
  return { journal: j, period };
}

async function updateDraftHeader({ orgId, journalId, actorUserId, payload }) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { journal } = await assertEditableJournal(client, { orgId, journalId });
    if (journal.created_by && String(journal.created_by) !== String(actorUserId)) {
      // Allow only creator to edit draft by default
      throw new AppError(403, "Only the creator can edit this draft journal");
    }

    // Resolve type id if typeCode provided
    let typeId = null;
    if (payload.typeCode) {
      const { rows: tRows } = await client.query(`SELECT id FROM journal_entry_types WHERE code=$1`, [payload.typeCode]);
      if (!tRows.length) throw new AppError(400, "Invalid journal entry type");
      typeId = tRows[0].id;
    }

    let periodId = payload.periodId || journal.period_id;
    if (payload.periodId) {
      const p = await getPeriodForUpdate(client, orgId, payload.periodId);
      if (p.status !== "open") throw new AppError(409, "Target period not open");
      periodId = p.id;
      if (payload.entryDate) assertEntryDateWithinPeriod(payload.entryDate, p);
    }

    if (payload.entryDate && !payload.periodId) {
      const p = await getPeriodForUpdate(client, orgId, journal.period_id);
      assertEntryDateWithinPeriod(payload.entryDate, p);
    }

    await client.query(
      `UPDATE journal_entries
       SET period_id = COALESCE($3, period_id),
           entry_date = COALESCE($4, entry_date),
           memo = CASE WHEN $5::text IS NOT NULL THEN $5 ELSE memo END,
           journal_entry_type_id = COALESCE($6, journal_entry_type_id),
           status='draft',
           rejected_at=NULL,
           rejected_by=NULL,
           rejection_reason=NULL,
           updated_at=NOW()
       WHERE organization_id=$1 AND id=$2`,
      [orgId, journalId, periodId, payload.entryDate || null, payload.memo === undefined ? null : payload.memo, typeId]
    );

    await client.query("COMMIT");
    return { journalId, status: "draft" };
  } catch (e) {
    try { await client.query("ROLLBACK"); } catch (_) {}
    throw e;
  } finally {
    client.release();
  }
}

async function replaceDraftLines({ orgId, journalId, actorUserId, lines }) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { journal } = await assertEditableJournal(client, { orgId, journalId });
    if (journal.created_by && String(journal.created_by) !== String(actorUserId)) {
      throw new AppError(403, "Only the creator can edit this draft journal");
    }

    const totals = sum2(lines || []);
    if (totals.debit !== totals.credit) throw new AppError(400, "Journal not balanced");

    // Validate accounts
    for (const l of lines) {
      const { rows: aRows } = await client.query(
        `SELECT is_postable, status FROM chart_of_accounts WHERE organization_id=$1 AND id=$2`,
        [orgId, l.accountId]
      );
      if (!aRows.length) throw new AppError(400, "Invalid accountId");
      if (!aRows[0].is_postable) throw new AppError(400, "Non-postable account used");
      if (aRows[0].status !== "active") throw new AppError(400, "Inactive account used");
    }

    const baseCurrency = await getOrgBaseCurrency(client, orgId);

    await client.query(`DELETE FROM journal_entry_lines WHERE journal_entry_id=$1`, [journalId]);

    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      const debitBI = parseDecimalToBigInt(l.debit || 0, 2);
      const creditBI = parseDecimalToBigInt(l.credit || 0, 2);
      const amountBaseBI = debitBI > 0n ? debitBI : creditBI;
      await client.query(
        `INSERT INTO journal_entry_lines
          (journal_entry_id, line_no, account_id, description, debit, credit, currency_code, fx_rate, amount_base)
         VALUES ($1,$2,$3,$4,$5,$6,$7,1,$8)`,
        [
          journalId,
          i + 1,
          l.accountId,
          l.description || null,
          bigIntToDecimalString(debitBI, 2),
          bigIntToDecimalString(creditBI, 2),
          baseCurrency,
          bigIntToDecimalString(amountBaseBI, 2)
        ]
      );
    }

    // If journal was rejected, revert back to draft
    await client.query(
      `UPDATE journal_entries
       SET status='draft', rejected_at=NULL, rejected_by=NULL, rejection_reason=NULL, updated_at=NOW()
       WHERE organization_id=$1 AND id=$2`,
      [orgId, journalId]
    );

    await client.query("COMMIT");
    return { journalId, status: "draft" };
  } catch (e) {
    try { await client.query("ROLLBACK"); } catch (_) {}
    throw e;
  } finally {
    client.release();
  }
}

async function submitDraftJournal({ orgId, journalId, actorUserId }) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows: jRows } = await client.query(
      `SELECT id, status, created_by, period_id, entry_date FROM journal_entries WHERE organization_id=$1 AND id=$2 FOR UPDATE`,
      [orgId, journalId]
    );
    if (!jRows.length) throw new AppError(404, "Journal not found");
    const j = jRows[0];
    if (j.status !== "draft") throw new AppError(409, "Only draft journals can be submitted");
    if (j.created_by && String(j.created_by) !== String(actorUserId)) {
      throw new AppError(403, "Only the creator can submit this journal");
    }

    const period = await getPeriodForUpdate(client, orgId, j.period_id);
    if (period.status !== "open") throw new AppError(409, "Period not open");
    assertEntryDateWithinPeriod(j.entry_date, period);

    const { rows: lines } = await client.query(
      `SELECT debit, credit FROM journal_entry_lines WHERE journal_entry_id=$1 ORDER BY line_no`,
      [journalId]
    );
    if (!lines.length) throw new AppError(400, "Journal has no lines");
    const totals = sum2(lines);
    if (totals.debit !== totals.credit) throw new AppError(400, "Journal not balanced");

    await client.query(
      `UPDATE journal_entries
       SET status='submitted', submitted_at=NOW(), submitted_by=$3, updated_at=NOW()
       WHERE organization_id=$1 AND id=$2`,
      [orgId, journalId, actorUserId]
    );

    await client.query("COMMIT");
    return { journalId, status: "submitted" };
  } catch (e) {
    try { await client.query("ROLLBACK"); } catch (_) {}
    throw e;
  } finally {
    client.release();
  }
}

async function approveSubmittedJournal({ orgId, journalId, actorUserId }) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows: jRows } = await client.query(
      `SELECT id, status, created_by FROM journal_entries WHERE organization_id=$1 AND id=$2 FOR UPDATE`,
      [orgId, journalId]
    );
    if (!jRows.length) throw new AppError(404, "Journal not found");
    const j = jRows[0];
    if (j.status !== "submitted") throw new AppError(409, "Only submitted journals can be approved");
    if (j.created_by && String(j.created_by) === String(actorUserId)) {
      throw new AppError(403, "Segregation of duties: creator cannot approve this journal");
    }
    await client.query(
      `UPDATE journal_entries
       SET status='approved', approved_at=NOW(), approved_by=$3, updated_at=NOW()
       WHERE organization_id=$1 AND id=$2`,
      [orgId, journalId, actorUserId]
    );
    await client.query("COMMIT");
    return { journalId, status: "approved" };
  } catch (e) {
    try { await client.query("ROLLBACK"); } catch (_) {}
    throw e;
  } finally {
    client.release();
  }
}

async function rejectSubmittedJournal({ orgId, journalId, actorUserId, reason }) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows: jRows } = await client.query(
      `SELECT id, status, created_by FROM journal_entries WHERE organization_id=$1 AND id=$2 FOR UPDATE`,
      [orgId, journalId]
    );
    if (!jRows.length) throw new AppError(404, "Journal not found");
    const j = jRows[0];
    if (j.status !== "submitted") throw new AppError(409, "Only submitted journals can be rejected");
    if (j.created_by && String(j.created_by) === String(actorUserId)) {
      throw new AppError(403, "Segregation of duties: creator cannot reject this journal");
    }
    await client.query(
      `UPDATE journal_entries
       SET status='rejected', rejected_at=NOW(), rejected_by=$3, rejection_reason=$4, updated_at=NOW()
       WHERE organization_id=$1 AND id=$2`,
      [orgId, journalId, actorUserId, reason]
    );
    await client.query("COMMIT");
    return { journalId, status: "rejected" };
  } catch (e) {
    try { await client.query("ROLLBACK"); } catch (_) {}
    throw e;
  } finally {
    client.release();
  }
}

async function cancelDraftJournal({ orgId, journalId, actorUserId }) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows: jRows } = await client.query(
      `SELECT id, status, created_by FROM journal_entries WHERE organization_id=$1 AND id=$2 FOR UPDATE`,
      [orgId, journalId]
    );
    if (!jRows.length) throw new AppError(404, "Journal not found");
    const j = jRows[0];
    if (j.status !== "draft" && j.status !== "rejected") {
      throw new AppError(409, "Only draft/rejected journals can be canceled");
    }
    if (j.created_by && String(j.created_by) !== String(actorUserId)) {
      throw new AppError(403, "Only the creator can cancel this journal");
    }
    await client.query(
      `UPDATE journal_entries
       SET status='canceled', canceled_at=NOW(), canceled_by=$3, updated_at=NOW()
       WHERE organization_id=$1 AND id=$2`,
      [orgId, journalId, actorUserId]
    );
    await client.query("COMMIT");
    return { journalId, status: "canceled" };
  } catch (e) {
    try { await client.query("ROLLBACK"); } catch (_) {}
    throw e;
  } finally {
    client.release();
  }
}

async function batchPostJournals({ orgId, actorUserId, journalIds, client: existingClient = null }) {
  // Best-effort batch: posts sequentially; each post is transactional.
  const results = [];
  for (const id of journalIds) {
    const r = await postDraftJournal({ orgId, journalId: id, actorUserId, client: existingClient });
    results.push(r);
  }
  return { count: results.length, results };
}

async function listJournals({ orgId, filters = {}, limit = 100, offset = 0 }) {
  const where = ["organization_id=$1"];
  const params = [orgId];
  let i = 2;

  if (filters.periodId) {
    where.push(`period_id=$${i++}`);
    params.push(filters.periodId);
  }
  if (filters.status) {
    where.push(`status=$${i++}`);
    params.push(filters.status);
  }
  if (filters.from) {
    where.push(`entry_date >= $${i++}::date`);
    params.push(filters.from);
  }
  if (filters.to) {
    where.push(`entry_date <= $${i++}::date`);
    params.push(filters.to);
  }

  params.push(limit);
  params.push(offset);

  const { rows } = await pool.query(
    `
    SELECT id, journal_entry_type_id, period_id, entry_date, memo, status,
           created_by, submitted_at, submitted_by, approved_at, approved_by,
           rejected_at, rejected_by, rejection_reason,
           canceled_at, canceled_by,
           created_at, updated_at
    FROM journal_entries
    WHERE ${where.join(" AND ")}
    ORDER BY entry_date DESC, created_at DESC
    LIMIT $${i++} OFFSET $${i++}
    `,
    params
  );
  return rows;
}


module.exports = {
  createDraftJournal,
  postDraftJournal,
  voidByReversal,
  reversePostedJournal,
  listJournals,
  getJournalWithLines,
  updateDraftHeader,
  replaceDraftLines,
  submitDraftJournal,
  approveSubmittedJournal,
  rejectSubmittedJournal,
  cancelDraftJournal,
  batchPostJournals
};
