BEGIN;

-- 1) Make entity_id nullable (some audited tables don't have NEW.id)
ALTER TABLE reporting_definition_audit
  ALTER COLUMN entity_id DROP NOT NULL;

-- 2) Optional but recommended: store a key snapshot for composite/no-id tables
ALTER TABLE reporting_definition_audit
  ADD COLUMN IF NOT EXISTS entity_key jsonb;

-- 3) Replace trigger function to avoid referencing NEW.id directly
CREATE OR REPLACE FUNCTION trg_audit_reporting_definition()
RETURNS TRIGGER AS $$
DECLARE
  v_org uuid;
  v_entity_type text;
  v_entity_id uuid;
  v_row jsonb;
BEGIN
  v_entity_type := TG_TABLE_NAME;

  -- Handle different tables
  IF (TG_TABLE_NAME = 'statement_line_accounts') THEN
    -- Get organization_id from parent statement_lines table
    IF (TG_OP = 'DELETE') THEN
      SELECT sl.organization_id INTO v_org
      FROM statement_lines sl
      WHERE sl.id = OLD.statement_line_id;
    ELSE
      SELECT sl.organization_id INTO v_org
      FROM statement_lines sl
      WHERE sl.id = NEW.statement_line_id;
    END IF;
  ELSE
    -- For other tables, use direct column
    IF (TG_OP = 'DELETE') THEN
      v_org := OLD.organization_id;
    ELSE
      v_org := NEW.organization_id;
    END IF;
  END IF;

  -- Safely try to read an "id" field if it exists; otherwise keep NULL.
  v_entity_id := NULL;
  BEGIN
    IF (TG_OP = 'DELETE') THEN
      v_row := to_jsonb(OLD);
    ELSE
      v_row := to_jsonb(NEW);
    END IF;
    
    IF (v_row ? 'id') AND (v_row->>'id') IS NOT NULL AND (v_row->>'id') <> '' THEN
      v_entity_id := (v_row->>'id')::uuid;
    END IF;
  EXCEPTION WHEN others THEN
    v_entity_id := NULL;
  END;

  IF (TG_OP = 'INSERT') THEN
    INSERT INTO reporting_definition_audit(
      organization_id, entity_type, entity_id, action, new_row, entity_key
    )
    VALUES (
      v_org, v_entity_type, v_entity_id, 'INSERT', to_jsonb(NEW), v_row
    );
    RETURN NEW;

  ELSIF (TG_OP = 'UPDATE') THEN
    INSERT INTO reporting_definition_audit(
      organization_id, entity_type, entity_id, action, old_row, new_row, entity_key
    )
    VALUES (
      v_org, v_entity_type, v_entity_id, 'UPDATE', to_jsonb(OLD), to_jsonb(NEW), v_row
    );
    RETURN NEW;

  ELSE -- DELETE
    INSERT INTO reporting_definition_audit(
      organization_id, entity_type, entity_id, action, old_row, entity_key
    )
    VALUES (
      v_org, v_entity_type, v_entity_id, 'DELETE', to_jsonb(OLD), v_row
    );
    RETURN OLD;
  END IF;
  
EXCEPTION WHEN others THEN
  -- Log error but don't fail the original operation
  RAISE WARNING 'Audit trigger failed: %', SQLERRM;
  IF (TG_OP = 'DELETE') THEN
    RETURN OLD;
  ELSE
    RETURN NEW;
  END IF;
END;
$$ LANGUAGE plpgsql;

COMMIT;
